#include "SDL/SDL.h"
#include "SDL\SDL_image.h"
#include "../DragonScript/include/dragonscript/dragonscript.hpp"
#include "../DragonScript/include/dragonscript/DSUtilsLib.hpp"
#include "../DragonScript/include/dragonscript/DSMathLib.hpp"

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;
using namespace dragonscript;


//class definitions for instantiation
Class* imageClass;
SDL_Surface* screen;

void PrintError(Error e)
{
	cout<<"error: "<<e.filename<<":"<<e.line<<": "<<e.message<<endl;
}

string ReadFile(const char *filename)
{
	ifstream file(filename);
	stringstream stream;
	string line;

	while(file.good())
	{
		getline(file,line);
		stream<<line<<endl;
	}

	return stream.str();
}

Value print(VirtualMachine* vm,Object* self)
{
	for(int i=0;i<vm->NumArgs();i++)
		vm->GetArg(i).Print();

	return Value::CreateNull();
}

class Input
{
public:
	static bool* prevKeys;
	static bool* curKeys;

	static void Init()
	{
		prevKeys = new bool[323];
		curKeys = new bool[323];
		for(int i=0;i<323;i++)
		{
			prevKeys[i]=false;
			curKeys[i]=false;
		}
	}

	static void PreUpdate()
	{
		for(int i=0;i<323;i++)
		{
			prevKeys[i]=curKeys[i];
			//curKeys[i]=false;
		}
	}

	static bool IsKeyDown(int index)
	{
		return curKeys[index];
	}

	static bool IsKeyUp(int index)
	{
		return !curKeys[index];
	}

	static bool IsKeyPressed(int index)
	{
		return !prevKeys[index] && curKeys[index];
	}

	static bool IsKeyReleased(int index)
	{
		return prevKeys[index] && !curKeys[index];
	}	
};

bool* Input::prevKeys=0;
bool* Input::curKeys=0;


class ScriptManager
{
	Compiler compiler;
	Assembly* lib;
	VirtualMachine vm;
	Object* game;

	vector<Class*> classes;

public:
	ScriptManager()
	{
	}

	void AddClass(Class* cls)
	{
		classes.push_back(cls);
	}

	void AddSourceFile(string filename)
	{
		compiler.AddSource(filename,ReadFile(filename.c_str()));
	}

	bool CompileScripts()
	{
		if(compiler.Compile())
		{
			return true;
		}
		return false;
	}

	//compiles scripts, creates instance of class derived from Game and stores it 
	//add all classes and sources before this method is called
	void Start()
	{
		//compile scripts
		bool res = CompileScripts();
		if(!res)
		{
			PrintError(compiler.GetError());
			return;
		}

		//add classes to assembly
		lib = compiler.GetAssembly();
		for(auto i:classes)
			lib->AddClass(i);

		//add few native helper functions
		lib->AddNativeFunction("print",print);

		DSMathLib::Install(lib);
		DSUtilsLib::Install(lib);
		
		vm.SetAssembly(lib);

		Class* gameClass = lib->GetClass("Game");
		if(!gameClass)
		{
			cout<<"couldnt find a Game class "<<endl;
			return;
		}

		game = vm.CreateObject(gameClass);
		if(!game)
		{
			cout<<"couldnt not create game instance"<<endl;
			return;
		}

		game->managed = false;
	}

	void RunInit()
	{
		if(!game)return;

		vm.ExecuteMemberFunction(game,"init");

		if(vm.HasError())
		{
			PrintError(vm.GetError());
			vm.ClearError();
		}
	}

	void RunUpdate(float dt)
	{
		if(!game)return;

		vm.AddArg(Value::CreateNumber(dt));
		vm.ExecuteMemberFunction(game,"update");

		if(vm.HasError())
		{
			PrintError(vm.GetError());
			vm.ClearError();
		}

	}

	void RunDraw()
	{
		if(!game)return;

		vm.ExecuteMemberFunction(game,"draw");

		if(vm.HasError())
		{
			PrintError(vm.GetError());
			vm.ClearError();
		}
	}

	~ScriptManager()
	{
		vm.DestroyObject(game);
	}
};

class ClassBuilder
{
public:
	Class* def;

	ClassBuilder()
	{
		def = NULL;
	}

	ClassBuilder* Start(string className)
	{
		def = new Class();
		def->name = className;

		return this;
	}

	ClassBuilder* Attrib(string name)
	{
		assert(def!=NULL);

		ClassAttrib attr;
		attr.name = name;
		attr.isStatic = false;
		attr.init = NULL;
		def->attribs.push_back(attr);

		return this;
	}

	ClassBuilder* StaticAttrib(string name)
	{
		assert(def!=NULL);

		ClassAttrib attr;
		attr.name = name;
		attr.isStatic = true;
		attr.init = NULL;
		def->attribs.push_back(attr);

		return this;
	}

	ClassBuilder* Constructor(NativeFunction native)
	{
		Function* func = new Function;
		func->name = def->name;
		func->isStatic = false;
		func->isNative = true;
		func->nativeFunction = native;

		def->methods[def->name]=func;
		return this;
	}

	ClassBuilder* Destructor(NativeFunction native)
	{
		Function* func = new Function;
		func->name = def->name;
		func->isStatic = false;
		func->isNative = true;
		func->nativeFunction = native;

		def->destructor = func;
		return this;
	}

	ClassBuilder* Method(string name,NativeFunction native)
	{
		Function* func = new Function;
		func->name = def->name;
		func->isStatic = false;
		func->isNative = true;
		func->nativeFunction = native;

		def->methods[name]=func;
		return this;
	}

	ClassBuilder* StaticMethod(string name,NativeFunction native)
	{
		Function* func = new Function;
		func->name = def->name;
		func->isStatic = true;
		func->isNative = true;
		func->nativeFunction = native;

		def->methods[name]=func;
		return this;
	}

	Class* Finish()
	{
		Class* c = def;
		def = NULL;

		return c;
	}
};

Value BlankFunction(VirtualMachine* vm,Object* self)
{
	return Value::CreateNull();
}



struct ImageRef
{

};

struct Image
{
	SDL_Surface* sprite;
	int refCount;
};

class Assets
{
	map<string,Image*> imageMap;
public:
	static Image* LoadImage(string imgName)
	{
		Image* image = new Image;
		image->sprite = IMG_Load(imgName.c_str());

		assert(image->sprite!=NULL);

		return image;
	}
};

#define EXPECT_STRING(vm,index) if(vm->GetArg(index).type!=ValueType::String){vm->RaiseError("expected a string argument");return Value::CreateNull();}
#define EXPECT_OBJECT(vm,index) if(vm->GetArg(index).type!=ValueType::Object){vm->RaiseError("expected an object");return Value::CreateNull();}
#define EXPECT_NUMBER(vm,index) if(vm->GetArg(index).type!=ValueType::Number){vm->RaiseError("expected a number");return Value::CreateNull();}

Value Assets_LoadImage(VirtualMachine* vm,Object* self)
{
	//first arg should be string
	EXPECT_STRING(vm,0);

	Value val = vm->GetArg(0);
	const char* filename = val.AsString();

	//load actual asset
	Image* img = Assets::LoadImage(filename);

	//create image Object and assign img to data
	Object* imgObject = vm->CreateObject(imageClass);
	imgObject->data = img;

	//return obj
	return Value::CreateObject(imgObject);
}

Value Image_Destruct(VirtualMachine* vm,Object* self)
{
	Image* img = (Image*)self->data;

	//free surface
	SDL_FreeSurface(img->sprite);

	//delete!
	delete img;

	return Value::CreateNull();
}

Value Canvas_DrawImage(VirtualMachine* vm,Object* self)
{
	//get object
	EXPECT_OBJECT(vm,0);
	EXPECT_NUMBER(vm,1);
	EXPECT_NUMBER(vm,2);

	Object* obj = vm->GetArg(0).AsObject();
	if(obj->typeName!="Image")
	{
		vm->RaiseError("you can only render an image");
		return Value::CreateNull();
	}
	//todo: validate obj->data is not null

	int x = (int)vm->GetArg(1).AsNumber();
	int y = (int)vm->GetArg(2).AsNumber();

	//blit!
	Image* img = (Image*)obj->data;
	SDL_Rect rect;
	rect.x = x;
	rect.y = y;
	//rect.w = img->sprite->w;
	//rect.h = img->sprite->h;

	SDL_BlitSurface(img->sprite,NULL,screen,&rect);

	return Value::CreateNull();
}

Value Input_IsKeyDown(VirtualMachine* vm,Object* self)
{
	EXPECT_NUMBER(vm,0);

	int index = (int)vm->GetArg(0).AsNumber();

	//todo: check if index is within the bounds
	
	bool res = Input::IsKeyDown(index);

	return Value::CreateBool(res);
}

Value Input_IsKeyUp(VirtualMachine* vm,Object* self)
{
	EXPECT_NUMBER(vm,0);

	int index = (int)vm->GetArg(0).AsNumber();

	//todo: check if index is within the bounds	
	bool res = Input::IsKeyUp(index);

	return Value::CreateBool(res);
}

/*
CURRENT ISSUE!
game instance and its vars are being garbage collected
*/
int main(int argc,char** argv)
{
	//script man
	ScriptManager scriptMan;

	//create classes
	ClassBuilder* builder = new ClassBuilder;

	Class* gfxClass = builder->Start("Canvas")
		->StaticMethod("drawImage",Canvas_DrawImage)/* void drawImage(img,x,y); */
		->Finish();

	Class* assetsClass = builder->Start("Assets")
		->StaticMethod("loadImage",Assets_LoadImage)/* Image loadImage(filename) */
		->Finish();

	Class* inputClass = builder->Start("Input")
		->StaticMethod("isKeyDown",Input_IsKeyDown)/* bool isKeyDown(index) */
		->StaticMethod("isKeyUp",Input_IsKeyUp)/* bool isKeyUp(index) */
		->Finish();

	//global
	imageClass = builder->Start("Image")
		->Attrib("width")
		->Attrib("height")
		->Destructor(Image_Destruct)//release resources
		->Finish();

	//add scripts
	scriptMan.AddSourceFile("scripts/game.ds");

	//add classes
	scriptMan.AddClass(assetsClass);
	scriptMan.AddClass(gfxClass);
	scriptMan.AddClass(imageClass);
	scriptMan.AddClass(inputClass);

	//add classes and sources before this funtion is called
	scriptMan.Start();

	SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO);

	screen = SDL_SetVideoMode(800,480,32,SDL_HWSURFACE);

	Input::Init();

	scriptMan.RunInit();

	int lastTime = SDL_GetTicks();
	bool done = false;
	while (!done)
	{
		SDL_Event evt;
		Input::PreUpdate();

		//handle events
		while(SDL_PollEvent(&evt))
		{
			switch (evt.type)
			{
			case SDL_QUIT:
				done = true;
				break;
			case SDL_KEYDOWN:
				Input::curKeys[evt.key.keysym.sym] = true;
				break;
			case SDL_KEYUP:
				Input::curKeys[evt.key.keysym.sym] = false;
				break;
			default:
				break;
			}
		}
		//get framerate
		int curTime = SDL_GetTicks();
		float dt = (curTime-lastTime)/1000.0f;
		lastTime = curTime;

		//cout<<dt<<endl;

		//update
		scriptMan.RunUpdate(dt);

		SDL_FillRect(screen,NULL,0xffffff);

		//render
		scriptMan.RunDraw();

		SDL_Flip(screen);
	}

	SDL_Quit();

	return 0;
}